from flask import Flask, request,render_template

app = Flask(__name__)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username=request.form['username']
        password = request.form['password']

        return render_template ('index.html')

        if username == 'admin' and password =='admin':
            return('Успешный вход!','success')
            return redirect(url_for('admin'))
        else:
            return('Neverniy parol ili login')
            return render_template('login.html')
    else:
        return render_template('login.html')

@app.route('/' , methods=['GET','POST'])
def index():
    return render_template('index.html')

@app.route('/admin')
def admin():
    bookings=[
         {'last_name': 'Петров', 'first_name': 'Иван', 'phone': '+7(800)555-35-35', 
         'check_in': '19.02.2020', 'check_out': '21.02.2020'},
        {'last_name': 'Иванов', 'first_name': 'Сергей', 'phone': '+7(800)555-35-35', 
         'check_in': '20.02.2020', 'check_out': '22.02.2020'},
        {'last_name': 'Сидоров', 'first_name': 'Алексей', 'phone': '+7(800)555-35-35', 
         'check_in': '21.02.2020', 'check_out': '23.02.2020'},
    ]
    return render_template('admin.html', bookings=bookings)

@app.route('/order', methods=['GET','POST'])
def order():
    if request.method =='POST':
        name=request.form.get('name')
        last_name=request.form.get('last_name')
        phone=request.form.get('phone')
        email=request.form.get('email')
        check_in=request.form.get('check_in')
        check_out=request.form.get('check_out')

        return('Заявка успешно отправлена!','succes')
        return redirect(url_for('order'))
    else:
        return render_template('order.html')






if __name__ == '__main__':
    app.run(debug=True)

